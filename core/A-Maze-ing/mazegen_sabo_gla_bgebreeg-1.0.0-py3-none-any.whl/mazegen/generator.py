"""Iterative stack-based maze generator with BFS solver.

Provides MazeGenerator which carves mazes using an explicit
stack (no recursion), stamps a 42 glyph of sealed cells, and
finds the shortest path via breadth-first search.
"""

import random
from collections import deque
from typing import Iterator, Optional

NORTH, EAST, SOUTH, WEST = 1, 2, 4, 8
FLIP = {NORTH: SOUTH, SOUTH: NORTH, EAST: WEST, WEST: EAST}
DELTA = {
    NORTH: (0, -1),
    EAST: (1, 0),
    SOUTH: (0, 1),
    WEST: (-1, 0),
}
LETTERS = {NORTH: "N", EAST: "E", SOUTH: "S", WEST: "W"}

_MIN_42 = 10

GLYPH_4 = [
    (0, 0), (0, 1), (0, 2),
    (1, 2),
    (2, 0), (2, 1), (2, 2), (2, 3), (2, 4),
]

GLYPH_2 = [
    (0, 0), (1, 0), (2, 0),
    (2, 1),
    (0, 2), (1, 2), (2, 2),
    (0, 3),
    (0, 4), (1, 4), (2, 4),
]


class MazeGenerator:
    """Stack-based maze generator with bitmask walls and BFS solver.

    Attributes:
        cols: Number of columns (width).
        rows: Number of rows (height).
        seed: Random seed for reproducibility.
        perfect: Whether to keep the maze as a spanning tree.
        walls: 2-D grid of wall bitmasks after build().
        carved: Set of (x, y) cells carved during generation.
    """

    def __init__(
        self,
        cols: int,
        rows: int,
        seed: Optional[int] = None,
        perfect: bool = True,
    ) -> None:
        """Create a new generator.

        Args:
            cols: Maze width in cells.
            rows: Maze height in cells.
            seed: Optional seed for deterministic output.
            perfect: If True every pair of cells has exactly
                     one connecting path.
        """
        self.cols = cols
        self.rows = rows
        self.seed = seed
        self.perfect = perfect
        self.walls: list[list[int]] = []
        self.carved: set[tuple[int, int]] = set()

    def _stamp_42(self) -> None:
        """Mark glyph cells as carved so the carver skips them."""
        if self.cols < _MIN_42 or self.rows < _MIN_42:
            print(
                "Warning: maze too small for the 42 pattern."
            )
            return

        ox = self.cols // 2 - 4
        oy = self.rows // 2 - 2

        for gx, gy in GLYPH_4:
            cx, cy = ox + gx, oy + gy
            if 0 <= cx < self.cols and 0 <= cy < self.rows:
                self.carved.add((cx, cy))

        for gx, gy in GLYPH_2:
            cx, cy = ox + gx + 4, oy + gy
            if 0 <= cx < self.cols and 0 <= cy < self.rows:
                self.carved.add((cx, cy))

    def _pick_start(
        self, preferred: tuple[int, int],
    ) -> tuple[int, int]:
        """Return preferred if valid, else first free cell.

        Args:
            preferred: Desired starting cell.

        Returns:
            An (x, y) cell that is in-bounds and not reserved.
        """
        px, py = preferred
        if (
            0 <= px < self.cols
            and 0 <= py < self.rows
            and preferred not in self.carved
        ):
            return preferred
        for r in range(self.rows):
            for c in range(self.cols):
                if (c, r) not in self.carved:
                    return (c, r)
        return (0, 0)

    def build(
        self, origin: tuple[int, int] = (0, 0),
    ) -> None:
        """Generate the maze with an iterative stack carver.

        Args:
            origin: Cell where carving begins.
        """
        if self.seed is not None:
            random.seed(self.seed)

        self.walls = [
            [0xF] * self.cols for _ in range(self.rows)
        ]
        self.carved = set()
        self._stamp_42()

        start = self._pick_start(origin)
        self.carved.add(start)
        stack: list[tuple[int, int]] = [start]

        while stack:
            cx, cy = stack[-1]
            neighbours = self._uncarved_around(cx, cy)
            if neighbours:
                d, nx, ny = random.choice(neighbours)
                self.walls[cy][cx] &= ~d
                self.walls[ny][nx] &= ~FLIP[d]
                self.carved.add((nx, ny))
                stack.append((nx, ny))
            else:
                stack.pop()

        if not self.perfect:
            self._break_walls()

    def build_animated(
        self, origin: tuple[int, int] = (0, 0),
    ) -> Iterator[tuple[int, int]]:
        """Like build() but yields every carved cell.

        Args:
            origin: Cell where carving begins.

        Yields:
            (x, y) of each newly opened cell.
        """
        if self.seed is not None:
            random.seed(self.seed)

        self.walls = [
            [0xF] * self.cols for _ in range(self.rows)
        ]
        self.carved = set()
        self._stamp_42()

        start = self._pick_start(origin)
        self.carved.add(start)
        yield start
        stack: list[tuple[int, int]] = [start]

        while stack:
            cx, cy = stack[-1]
            neighbours = self._uncarved_around(cx, cy)
            if neighbours:
                d, nx, ny = random.choice(neighbours)
                self.walls[cy][cx] &= ~d
                self.walls[ny][nx] &= ~FLIP[d]
                self.carved.add((nx, ny))
                stack.append((nx, ny))
                yield (nx, ny)
            else:
                stack.pop()

        if not self.perfect:
            self._break_walls()

    def _uncarved_around(
        self, x: int, y: int,
    ) -> list[tuple[int, int, int]]:
        """Return (direction, nx, ny) for uncarved neighbours.

        Args:
            x: Column of the current cell.
            y: Row of the current cell.

        Returns:
            List of (direction_bit, nx, ny) tuples.
        """
        out: list[tuple[int, int, int]] = []
        for d, (dx, dy) in DELTA.items():
            nx, ny = x + dx, y + dy
            if (
                0 <= nx < self.cols
                and 0 <= ny < self.rows
                and (nx, ny) not in self.carved
            ):
                out.append((d, nx, ny))
        return out

    def _break_walls(self) -> None:
        """Remove random walls to add loops (non-perfect mode)."""
        pool: list[tuple[int, int, int]] = []
        for r in range(self.rows):
            for c in range(self.cols):
                if self.walls[r][c] == 0xF:
                    continue
                for d in (EAST, SOUTH):
                    if not (self.walls[r][c] & d):
                        continue
                    dx, dy = DELTA[d]
                    nc, nr = c + dx, r + dy
                    if (
                        0 <= nc < self.cols
                        and 0 <= nr < self.rows
                        and self.walls[nr][nc] != 0xF
                    ):
                        pool.append((c, r, d))
        random.shuffle(pool)
        limit = max(1, len(pool) // 8)
        for c, r, d in pool[:limit]:
            dx, dy = DELTA[d]
            nc, nr = c + dx, r + dy
            self.walls[r][c] &= ~d
            self.walls[nr][nc] &= ~FLIP[d]

    def shortest_path(
        self,
        start: tuple[int, int],
        end: tuple[int, int],
    ) -> str:
        """BFS shortest path between two cells.

        Args:
            start: Source cell (x, y).
            end: Destination cell (x, y).

        Returns:
            Direction string like "EESSW", or "" if unreachable.
        """
        seen: set[tuple[int, int]] = {start}
        queue: deque[tuple[tuple[int, int], str]] = deque(
            [(start, "")],
        )
        while queue:
            (x, y), trail = queue.popleft()
            if (x, y) == end:
                return trail
            for d, (dx, dy) in DELTA.items():
                nx, ny = x + dx, y + dy
                if (
                    0 <= nx < self.cols
                    and 0 <= ny < self.rows
                    and not (self.walls[y][x] & d)
                    and (nx, ny) not in seen
                ):
                    seen.add((nx, ny))
                    queue.append(
                        ((nx, ny), trail + LETTERS[d]),
                    )
        return ""

    def check_no_3x3_open(self) -> bool:
        """Verify no 3x3 fully-open area exists.

        Returns:
            True when the constraint holds.
        """
        for r in range(self.rows - 2):
            for c in range(self.cols - 2):
                blocked = False
                for dr in range(3):
                    for dc in range(3):
                        if dc < 2 and (
                            self.walls[r + dr][c + dc] & EAST
                        ):
                            blocked = True
                        if dr < 2 and (
                            self.walls[r + dr][c + dc] & SOUTH
                        ):
                            blocked = True
                        if blocked:
                            break
                    if blocked:
                        break
                if not blocked:
                    return False
        return True

    def hex_rows(self) -> list[str]:
        """Return one hex string per row for the output file.

        Returns:
            List of strings, each cell a single hex digit.
        """
        return [
            "".join(format(c, "X") for c in row)
            for row in self.walls
        ]
