"""Reusable maze generator package."""

from .generator import MazeGenerator

__all__ = ["MazeGenerator"]
